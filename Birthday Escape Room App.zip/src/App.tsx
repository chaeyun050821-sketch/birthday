import {
  useState, useEffect, useRef, useCallback, useMemo
} from 'react'

/* ══════════════════════════════════════════════
   QUEST DATA
══════════════════════════════════════════════ */
type Tier = 'warmup' | 'middle' | 'hidden' | 'final'

interface Quest {
  id: string
  tier: Tier
  title: string
  subtitle: string
  baseReward: number
  question: string
  hint: string
  answers: string[]
  emoji: string
}

const HINT_PENALTY = 3000

const QUESTS: Quest[] = [
  // ── 워밍업 5 × 10,000
  { id:'w1', tier:'warmup', title:'첫 만남', subtitle:'우리가 처음 마주친 그 날', baseReward:10000,
    question:'우리가 처음 만난 날짜는? (월/일)', hint:'그날 너는 파란 후드티를 입고 있었어 🩵',
    answers:['3/15','03/15','3월 15일','03월 15일'], emoji:'🗓️' },
  { id:'w2', tier:'warmup', title:'최애 음식', subtitle:'내가 제일 좋아하는 걸 알아?', baseReward:10000,
    question:'내가 가장 좋아하는 음식은?', hint:'노란색이고, 면이야 🍜',
    answers:['라면','라볶이','짜장면'], emoji:'🍜' },
  { id:'w3', tier:'warmup', title:'첫 여행', subtitle:'바다 냄새가 나지 않아?', baseReward:10000,
    question:'우리가 처음 함께 떠난 여행지는?', hint:'바다 보이는 카페에서 빙수 먹었잖아 🍧',
    answers:['강릉','gangneung'], emoji:'🌊' },
  { id:'w4', tier:'warmup', title:'첫 마디', subtitle:'처음 건넨 말 기억해?', baseReward:10000,
    question:'내가 처음 너한테 뭐라고 말을 걸었어? (세 글자)',
    hint:'도서관에서 질문이었어 📚',
    answers:['자리야','자리 있어','자리있어'], emoji:'💬' },
  { id:'w5', tier:'warmup', title:'소소한 습관', subtitle:'매일 밤의 루틴', baseReward:10000,
    question:'잠들기 전 내가 꼭 하는 것은?', hint:'너랑 연결되어 있는 그것 🌙',
    answers:['통화','전화','야통','야간통화','전화통화'], emoji:'🌙' },

  // ── 미들 보스 5 × 20,000
  { id:'m1', tier:'middle', title:'숨겨진 단서', subtitle:'방 어딘가를 뒤져봐', baseReward:20000,
    question:'책상 위 파란 노트 첫 페이지에 적힌 네 자리 숫자는?',
    hint:'직접 가서 찾아봐야 해 📒 (책상 위 파란 노트)',
    answers:['0315','0 3 1 5'], emoji:'📒' },
  { id:'m2', tier:'middle', title:'암호 해독', subtitle:'이 메시지를 해석해봐', baseReward:20000,
    question:'ROT13으로 암호화된 문자야: "UNPXRE" — 원래 단어는?',
    hint:'알파벳을 13칸 앞으로 밀면 돼. N→A, O→B... 🔐',
    answers:['hacker','HACKER'], emoji:'🔐' },
  { id:'m3', tier:'middle', title:'신호 및 시스템', subtitle:'전공자 맞지?', baseReward:20000,
    question:'N-point DFT를 FFT로 계산할 때 시간 복잡도는?',
    hint:'Cooley–Tukey 알고리즘이 핵심 🦋',
    answers:['o(n log n)','nlogn','n log n','o(nlogn)','O(NlogN)'], emoji:'📡' },
  { id:'m4', tier:'middle', title:'알고리즘', subtitle:'탐색의 예술', baseReward:20000,
    question:'정렬된 배열에서 이진 탐색의 최악 시간 복잡도는?',
    hint:'탐색 범위가 매번 절반씩 줄어들지 ✂️',
    answers:['o(log n)','log n','o(logn)','θ(log n)'], emoji:'🔍' },
  { id:'m5', tier:'middle', title:'추억 퍼즐', subtitle:'잘 생각해봐', baseReward:20000,
    question:'우리가 처음 손을 잡은 건 어떤 날이었어? (한 단어)',
    hint:'비가 엄청 왔었는데... ☔',
    answers:['비오는날','비','우천','장마'], emoji:'☔' },

  // ── 히든 보너스 × 50,000
  { id:'hidden', tier:'hidden', title:'⚡ 히든 미션', subtitle:'30초 타임어택!', baseReward:50000,
    question:'내 핸드폰 잠금 비밀번호 앞 4자리는?',
    hint:'내 생일이랑 관련 있어 🎂',
    answers:['1234','0101'], emoji:'⚡' },

  // ── 파이널 보스 × 100,000
  { id:'final', tier:'final', title:'👑 파이널 보스', subtitle:'마지막 문이 열릴 준비가 됐어?', baseReward:100000,
    question:'우리가 처음 "좋아해"라고 말한 장소 이름은?',
    hint:'그때 별이 엄청 많았는데... ⭐',
    answers:['한강','한강공원','반포한강공원','여의도한강공원'], emoji:'👑' },
]

const WARMUP_IDS  = QUESTS.filter(q=>q.tier==='warmup').map(q=>q.id)
const MIDDLE_IDS  = QUESTS.filter(q=>q.tier==='middle').map(q=>q.id)
const MAX_LIVES   = 5
const TOTAL_BASE  = QUESTS.reduce((s,q)=>s+q.baseReward,0)

/* ══════════════════════════════════════════════
   TIER STYLE CONFIG
══════════════════════════════════════════════ */
const TIER = {
  warmup: { label:'워밍업', en:'WARM-UP',      color:'#16a34a', light:'#dcfce7', border:'#86efac' },
  middle: { label:'미들 보스', en:'MIDDLE BOSS', color:'#2563eb', light:'#dbeafe', border:'#93c5fd' },
  hidden: { label:'히든 보너스', en:'HIDDEN BONUS',color:'#d97706', light:'#fef3c7', border:'#fcd34d' },
  final:  { label:'파이널 보스', en:'FINAL BOSS',  color:'#dc2626', light:'#fee2e2', border:'#fca5a5' },
}

/* ══════════════════════════════════════════════
   COUNT-UP HOOK
══════════════════════════════════════════════ */
function useCountUp(target: number, duration = 600) {
  const [display, setDisplay] = useState(target)
  const raf = useRef<number>(0)
  const prev = useRef(target)

  useEffect(() => {
    const from = prev.current
    const diff = target - from
    if (diff === 0) return
    const start = performance.now()
    const step = (now: number) => {
      const p = Math.min((now - start) / duration, 1)
      const ease = 1 - Math.pow(1 - p, 3)
      setDisplay(Math.round(from + diff * ease))
      if (p < 1) raf.current = requestAnimationFrame(step)
      else prev.current = target
    }
    raf.current = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf.current)
  }, [target, duration])

  return display
}

/* ══════════════════════════════════════════════
   CONFETTI
══════════════════════════════════════════════ */
interface CP { id:number; x:number; color:string; size:number; dur:number; del:number }
function mkConfetti(n=70): CP[] {
  const cols = ['#dc2626','#ef4444','#fbbf24','#111','#6b7280','#fff','#f87171']
  return Array.from({length:n},(_,i)=>({
    id:i, x:Math.random()*100, color:cols[i%cols.length],
    size:6+Math.random()*8, dur:2.2+Math.random()*2, del:Math.random()*1.2,
  }))
}

/* ══════════════════════════════════════════════
   FLYING COIN
══════════════════════════════════════════════ */
interface Coin { id:number; x:number; y:number }
let coinId = 0

/* ══════════════════════════════════════════════
   LIVES DISPLAY
══════════════════════════════════════════════ */
function Lives({ lives, max }: { lives:number; max:number }) {
  return (
    <div className="flex gap-1 items-center">
      {Array.from({length:max},(_,i)=>(
        <span
          key={i}
          className="text-lg select-none transition-all duration-300"
          style={{ opacity: i < lives ? 1 : 0.18, filter: i < lives ? 'none' : 'grayscale(1)' }}
        >
          ❤️
        </span>
      ))}
    </div>
  )
}

/* ══════════════════════════════════════════════
   STICKY HEADER
══════════════════════════════════════════════ */
function Header({
  earned, lives, poppingMoney,
}: { earned:number; lives:number; poppingMoney:boolean }) {
  const displayed = useCountUp(earned, 700)
  return (
    <div
      className="sticky top-0 z-30 flex items-center justify-between px-4 py-3"
      style={{
        background:'rgba(255,255,255,0.92)',
        backdropFilter:'blur(12px)',
        borderBottom:'1.5px solid #f3f4f6',
      }}
    >
      <Lives lives={lives} max={MAX_LIVES} />
      <div className={`flex items-center gap-2 ${poppingMoney ? 'money-pop' : ''}`}>
        <span className="text-xl">💰</span>
        <span
          className="font-black text-lg tabular-nums"
          style={{ color:'#dc2626', fontFamily:'JetBrains Mono, monospace' }}
        >
          {displayed.toLocaleString()}원
        </span>
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════
   HINT BUTTON with penalty warning
══════════════════════════════════════════════ */
function HintButton({
  onReveal, revealed, hint, disabled,
}: { onReveal:()=>void; revealed:boolean; hint:string; disabled:boolean }) {
  const [confirming, setConfirming] = useState(false)

  if (revealed) return (
    <div className="rounded-xl px-4 py-3 text-sm text-gray-500 text-center bg-gray-50 border border-dashed border-gray-200">
      {hint}
    </div>
  )

  if (confirming) return (
    <div className="rounded-xl border-2 border-red-200 bg-red-50 p-3 text-center">
      <p className="text-red-600 font-bold text-sm mb-2">
        ⚠️ 힌트를 보면 -{HINT_PENALTY.toLocaleString()}원 차감!
      </p>
      <p className="text-gray-500 text-xs mb-3">그래도 볼 거야?</p>
      <div className="flex gap-2 justify-center">
        <button
          onClick={()=>{setConfirming(false); onReveal()}}
          className="px-4 py-1.5 rounded-lg bg-red-600 text-white text-xs font-bold cursor-pointer hover:bg-red-700 transition-colors"
        >
          차감하고 볼게
        </button>
        <button
          onClick={()=>setConfirming(false)}
          className="px-4 py-1.5 rounded-lg bg-white border border-gray-200 text-gray-600 text-xs font-bold cursor-pointer hover:bg-gray-50 transition-colors"
        >
          아니, 됐어
        </button>
      </div>
    </div>
  )

  return (
    <button
      onClick={()=>!disabled && setConfirming(true)}
      disabled={disabled}
      className="w-full text-center text-xs font-mono text-gray-300 hover:text-red-400 transition-colors cursor-pointer underline underline-offset-2 disabled:cursor-not-allowed"
    >
      힌트 보기 (-{HINT_PENALTY.toLocaleString()}원 패널티)
    </button>
  )
}

/* ══════════════════════════════════════════════
   QUEST MODAL
══════════════════════════════════════════════ */
function QuestModal({
  quest, livesLeft, onSolve, onWrong, onClose,
}: {
  quest: Quest
  livesLeft: number
  onSolve: (q: Quest, hintUsed: boolean, el: HTMLElement) => void
  onWrong: () => void
  onClose: () => void
}) {
  const cfg = TIER[quest.tier]
  const [input, setInput] = useState('')
  const [status, setStatus] = useState<'idle'|'wrong'|'correct'>('idle')
  const [hintUsed, setHintUsed] = useState(false)
  const [timeLeft, setTimeLeft] = useState<number|null>(quest.tier==='hidden' ? 30 : null)
  const [timedOut, setTimedOut] = useState(false)
  const shakeRef  = useRef<HTMLDivElement>(null)
  const inputRef  = useRef<HTMLInputElement>(null)
  const solveRef  = useRef<HTMLButtonElement>(null)
  const gameOver  = livesLeft === 0

  useEffect(()=>{ setTimeout(()=>inputRef.current?.focus(), 200) }, [])

  useEffect(()=>{
    if (timeLeft===null || status==='correct' || timedOut) return
    if (timeLeft<=0){ setTimedOut(true); return }
    const t = setTimeout(()=>setTimeLeft(s=>(s??1)-1), 1000)
    return ()=>clearTimeout(t)
  },[timeLeft, status, timedOut])

  const check = useCallback(()=>{
    if (timedOut || status==='correct' || gameOver) return
    const val = input.trim().toLowerCase()
    if (quest.answers.map(a=>a.toLowerCase()).includes(val)) {
      setStatus('correct')
      setTimeout(()=>onSolve(quest, hintUsed, solveRef.current!), 500)
    } else {
      setStatus('wrong')
      onWrong()
      shakeRef.current?.classList.remove('shake')
      void shakeRef.current?.offsetWidth
      shakeRef.current?.classList.add('shake')
      setTimeout(()=>setStatus('idle'), 1400)
    }
  }, [input, quest, hintUsed, onSolve, onWrong, timedOut, status, gameOver])

  const timeRatio  = timeLeft!==null ? timeLeft/30 : 1
  const timeColor  = timeRatio>0.5 ? '#16a34a' : timeRatio>0.25 ? '#d97706' : '#dc2626'
  const effectiveReward = quest.baseReward - (hintUsed ? HINT_PENALTY : 0)

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center p-4"
      style={{background:'rgba(0,0,0,0.45)', backdropFilter:'blur(6px)'}}
      onClick={e=>e.target===e.currentTarget && onClose()}
    >
      <div
        ref={shakeRef}
        className="w-full max-w-md rounded-3xl overflow-hidden slide-up"
        style={{
          background:'#ffffff',
          border:`2px solid ${cfg.border}`,
          boxShadow:'0 20px 60px rgba(0,0,0,0.18)',
        }}
      >
        {/* Tier banner */}
        <div className="px-5 py-3 flex items-center justify-between" style={{background:cfg.light}}>
          <div className="flex items-center gap-2">
            <span className="text-xl">{quest.emoji}</span>
            <span className="font-bold text-sm" style={{color:cfg.color}}>{cfg.label}</span>
          </div>
          <div className="flex items-center gap-2">
            <span
              className="font-black text-base tabular-nums"
              style={{color: effectiveReward<quest.baseReward ? '#dc2626' : cfg.color, fontFamily:'JetBrains Mono,monospace'}}
            >
              {effectiveReward.toLocaleString()}원
            </span>
            {hintUsed && (
              <span className="text-xs text-red-400 font-mono">(-{HINT_PENALTY.toLocaleString()})</span>
            )}
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-lg cursor-pointer ml-1">×</button>
          </div>
        </div>

        <div className="px-6 py-5">
          {/* Timer */}
          {timeLeft!==null && (
            <div className="mb-4">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-gray-400 font-mono">TIMER</span>
                <span className="font-black text-sm tabular-nums" style={{color:timeColor, fontFamily:'JetBrains Mono,monospace'}}>
                  {timedOut ? '시간 초과!' : `${timeLeft}s`}
                </span>
              </div>
              <div className="h-2 rounded-full bg-gray-100 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-1000"
                  style={{width:`${timeRatio*100}%`, background:timeColor}}
                />
              </div>
            </div>
          )}

          <h2 className="font-black text-xl text-gray-900 mb-0.5">{quest.title}</h2>
          <p className="text-gray-400 text-sm mb-5">{quest.subtitle}</p>

          {/* Question box */}
          <div
            className="rounded-2xl px-5 py-4 mb-5 text-center"
            style={{background:cfg.light, border:`1.5px solid ${cfg.border}`}}
          >
            <p className="font-bold text-gray-800 text-sm leading-relaxed">{quest.question}</p>
          </div>

          {/* Lives warning */}
          {livesLeft <= 2 && livesLeft > 0 && (
            <div className="mb-3 rounded-xl bg-red-50 border border-red-200 px-4 py-2 text-center">
              <p className="text-red-600 text-xs font-bold">
                ⚠️ 기회가 {livesLeft}번밖에 안 남았어!
              </p>
            </div>
          )}
          {gameOver && (
            <div className="mb-3 rounded-xl bg-gray-100 border border-gray-200 px-4 py-2 text-center">
              <p className="text-gray-500 text-xs font-bold">기회를 전부 써버렸어 😢</p>
            </div>
          )}

          {timedOut ? (
            <div className="text-center py-4">
              <p className="text-red-500 font-black text-lg mb-2">⏰ 타임 오버!</p>
              <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-sm cursor-pointer">
                닫기
              </button>
            </div>
          ) : (
            <>
              <input
                ref={inputRef}
                className="w-full rounded-xl px-4 py-3 text-sm mb-2 font-mono transition-all duration-150"
                style={{
                  background:'#f9fafb',
                  border:`1.5px solid ${status==='wrong'?'#dc2626':status==='correct'?'#16a34a':'#e5e7eb'}`,
                  color:'#111',
                  outline:'none',
                }}
                onFocus={e=>{ if(status==='idle') e.target.style.borderColor=cfg.color }}
                onBlur={e=>{ if(status==='idle') e.target.style.borderColor='#e5e7eb' }}
                type="text"
                placeholder="정답 입력..."
                value={input}
                onChange={e=>setInput(e.target.value)}
                onKeyDown={e=>e.key==='Enter'&&check()}
                disabled={status==='correct'||gameOver}
                autoComplete="off"
                spellCheck={false}
              />
              <div className="h-4 mb-3 text-center">
                {status==='wrong' && (
                  <p className="text-red-500 text-xs font-mono">✗ 틀렸어! 기회 -{1}회 차감</p>
                )}
                {status==='correct' && (
                  <p className="text-green-600 text-xs font-mono">✓ 정답! +{effectiveReward.toLocaleString()}원</p>
                )}
              </div>

              <button
                ref={solveRef}
                onClick={check}
                disabled={!input.trim()||status==='correct'||gameOver}
                className="w-full rounded-xl py-3 font-black text-sm cursor-pointer transition-all duration-150 mb-4 disabled:opacity-30 disabled:cursor-not-allowed"
                style={{
                  background: gameOver ? '#e5e7eb' : '#dc2626',
                  color:'#fff',
                }}
                onMouseEnter={e=>{ if(!e.currentTarget.disabled) e.currentTarget.style.background='#b91c1c' }}
                onMouseLeave={e=>{ if(!e.currentTarget.disabled) e.currentTarget.style.background='#dc2626' }}
              >
                확인 →
              </button>

              <HintButton
                onReveal={()=>setHintUsed(true)}
                revealed={hintUsed}
                hint={quest.hint}
                disabled={gameOver}
              />
            </>
          )}
        </div>
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════
   QUEST CARD
══════════════════════════════════════════════ */
function QuestCard({
  quest, solved, locked, gameOver, onClick,
}: { quest:Quest; solved:boolean; locked:boolean; gameOver:boolean; onClick:()=>void }) {
  const cfg = TIER[quest.tier]
  const clickable = !locked && !solved && !gameOver

  return (
    <button
      onClick={clickable ? onClick : undefined}
      disabled={!clickable}
      className="w-full text-left rounded-2xl px-4 py-3.5 transition-all duration-200 group"
      style={{
        background: solved ? cfg.light : locked||gameOver ? '#f9fafb' : '#fff',
        border: `1.5px solid ${solved ? cfg.border : locked||gameOver ? '#f3f4f6' : '#e5e7eb'}`,
        cursor: clickable ? 'pointer' : 'not-allowed',
        opacity: locked ? 0.5 : 1,
        boxShadow: solved ? `0 2px 12px ${cfg.color}22` : 'none',
      }}
      onMouseEnter={e=>{ if(clickable) e.currentTarget.style.borderColor=cfg.color; if(clickable) e.currentTarget.style.boxShadow=`0 4px 16px ${cfg.color}22` }}
      onMouseLeave={e=>{ e.currentTarget.style.borderColor=solved?cfg.border:locked||gameOver?'#f3f4f6':'#e5e7eb'; e.currentTarget.style.boxShadow=solved?`0 2px 12px ${cfg.color}22`:'none' }}
    >
      <div className="flex items-center gap-3">
        <div className="text-2xl shrink-0">{solved ? '✅' : locked ? '🔒' : quest.emoji}</div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span
              className="font-black text-sm"
              style={{ color: solved ? cfg.color : locked||gameOver ? '#9ca3af' : '#111' }}
            >
              {quest.title}
            </span>
            {solved && <span className="text-xs font-mono px-1.5 py-0.5 rounded-md" style={{background:cfg.light,color:cfg.color}}>클리어</span>}
          </div>
          <p className="text-gray-400 text-xs mt-0.5">{quest.subtitle}</p>
        </div>
        <div
          className="font-black text-sm tabular-nums shrink-0"
          style={{ color: solved ? cfg.color : locked||gameOver ? '#d1d5db' : '#374151', fontFamily:'JetBrains Mono,monospace' }}
        >
          {quest.baseReward.toLocaleString()}원
        </div>
      </div>
    </button>
  )
}

/* ══════════════════════════════════════════════
   TIER SECTION HEADER
══════════════════════════════════════════════ */
function TierHeader({ tier, earnedCount, total }: { tier:Tier; earnedCount:number; total:number }) {
  const cfg = TIER[tier]
  return (
    <div className="flex items-center gap-3 mb-2">
      <span className="text-xs font-black font-mono tracking-widest" style={{color:cfg.color}}>{cfg.en}</span>
      <div className="flex-1 h-px" style={{background:cfg.border}} />
      <span className="text-xs text-gray-400 font-mono">{earnedCount}/{total}</span>
    </div>
  )
}

/* ══════════════════════════════════════════════
   FLYING COINS (overlay)
══════════════════════════════════════════════ */
function CoinOverlay({ coins }: { coins: Coin[] }) {
  return (
    <>
      {coins.map(c=>(
        <div
          key={c.id}
          className="coin-particle"
          style={{ left:c.x, top:c.y, position:'fixed' }}
        >
          🪙
        </div>
      ))}
    </>
  )
}

/* ══════════════════════════════════════════════
   GAME OVER BANNER
══════════════════════════════════════════════ */
function GameOverBanner({ earned }: { earned:number }) {
  return (
    <div
      className="mx-4 mb-4 rounded-2xl px-5 py-4 text-center slide-up"
      style={{background:'#fee2e2', border:'2px solid #fca5a5'}}
    >
      <p className="text-2xl mb-1">💀</p>
      <p className="font-black text-red-700 text-base mb-1">기회 소진!</p>
      <p className="text-red-500 text-sm">
        남은 퀘스트는 잠겼어. 현재까지 획득한 <strong>{earned.toLocaleString()}원</strong>만 수령 가능해.
      </p>
    </div>
  )
}

/* ══════════════════════════════════════════════
   FINAL CELEBRATION SCREEN
══════════════════════════════════════════════ */
function FinalScreen({ earned, onClose }: { earned:number; onClose:()=>void }) {
  const [confetti] = useState(mkConfetti(80))
  const [phase, setPhase] = useState<'reveal'|'pay'>('reveal')
  const displayed = useCountUp(earned, 900)

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center p-6 overflow-auto"
      style={{background:'rgba(255,255,255,0.97)'}}
    >
      {confetti.map(c=>(
        <div key={c.id} className="confetti-piece"
          style={{left:`${c.x}%`,width:c.size,height:c.size,background:c.color,borderRadius:'2px',
            animationDuration:`${c.dur}s`,animationDelay:`${c.del}s`}} />
      ))}

      {phase==='reveal' && (
        <div className="text-center slide-up max-w-sm w-full">
          <div className="text-6xl mb-4">🏆</div>
          <h1 className="shimmer-red text-4xl font-black mb-2">탈출 성공!</h1>
          <p className="text-gray-400 font-mono text-sm mb-8">ALL STAGES CLEARED</p>

          <div className="bg-red-50 border-2 border-red-200 rounded-3xl p-6 mb-6">
            <p className="text-gray-500 text-sm mb-1 font-mono">총 획득 상금</p>
            <p
              className="font-black text-5xl tabular-nums mb-1"
              style={{color:'#dc2626', fontFamily:'JetBrains Mono,monospace'}}
            >
              {displayed.toLocaleString()}
            </p>
            <p className="text-red-400 font-black text-2xl">원</p>
          </div>

          <div className="bg-gray-50 border border-gray-200 rounded-2xl p-5 mb-6 text-left">
            <p className="text-red-500 font-mono text-xs mb-3 uppercase tracking-widest">🎀 생일 메시지</p>
            <p className="text-gray-700 text-sm leading-relaxed mb-4">
              이 퀴즈 다 맞혔다는 건 우리 추억을 전부 기억하고 있다는 거잖아. 그게 제일 좋아. 생일 축하해! 💜
            </p>
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
              <p className="text-amber-600 font-mono text-xs mb-1">🎁 현금 봉투 위치</p>
              <p className="text-gray-800 font-black text-sm">책상 서랍 두 번째 칸 — 빨간 봉투 💌</p>
            </div>
          </div>

          <button
            onClick={()=>setPhase('pay')}
            className="w-full rounded-2xl py-4 font-black text-white text-base cursor-pointer transition-all"
            style={{background:'#dc2626'}}
            onMouseEnter={e=>{ e.currentTarget.style.background='#b91c1c' }}
            onMouseLeave={e=>{ e.currentTarget.style.background='#dc2626' }}
          >
            💸 상금 수령하기 →
          </button>
        </div>
      )}

      {phase==='pay' && (
        <div className="text-center slide-up max-w-sm w-full">
          <div className="text-5xl mb-4">💸</div>
          <h2 className="font-black text-2xl text-gray-900 mb-1">상금 수령</h2>
          <p className="text-gray-400 font-mono text-sm mb-6">{earned.toLocaleString()}원</p>

          {/* Toss style */}
          <div
            className="rounded-2xl p-5 mb-3 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]"
            style={{background:'#3182f6'}}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-xl">💙</div>
              <div className="text-left flex-1">
                <p className="text-white font-black text-base">토스로 받기</p>
                <p className="text-blue-200 text-xs font-mono">Toss 송금 받기</p>
              </div>
              <span className="text-white font-black">{earned.toLocaleString()}원</span>
            </div>
          </div>

          {/* KakaoPay style */}
          <div
            className="rounded-2xl p-5 mb-3 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]"
            style={{background:'#FAE100'}}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-black/10 flex items-center justify-center text-xl">💛</div>
              <div className="text-left flex-1">
                <p className="text-gray-900 font-black text-base">카카오페이로 받기</p>
                <p className="text-yellow-700 text-xs font-mono">KakaoPay 송금 받기</p>
              </div>
              <span className="text-gray-900 font-black">{earned.toLocaleString()}원</span>
            </div>
          </div>

          {/* Cash */}
          <div
            className="rounded-2xl p-5 mb-6 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]"
            style={{background:'#f9fafb', border:'2px solid #e5e7eb'}}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center text-xl">💵</div>
              <div className="text-left flex-1">
                <p className="text-gray-900 font-black text-base">현금 봉투로 받기</p>
                <p className="text-gray-400 text-xs font-mono">책상 서랍 두 번째 칸 빨간 봉투</p>
              </div>
              <span className="text-gray-700 font-black">{earned.toLocaleString()}원</span>
            </div>
          </div>

          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-sm cursor-pointer">
            처음으로 돌아가기
          </button>
        </div>
      )}
    </div>
  )
}

/* ══════════════════════════════════════════════
   PROGRESS BAR (inline, in main view)
══════════════════════════════════════════════ */
function RewardProgress({ earned, total }: { earned:number; total:number }) {
  const pct = Math.round((earned/total)*100)
  return (
    <div className="px-4 mb-5">
      <div className="flex justify-between items-end mb-2">
        <span className="text-xs text-gray-400 font-mono">획득 진행률</span>
        <span className="text-xs font-black font-mono" style={{color:'#dc2626'}}>{pct}%</span>
      </div>
      <div className="h-3 rounded-full bg-gray-100 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{width:`${pct}%`, background:'linear-gradient(90deg,#dc2626,#ef4444,#f87171)'}}
        />
      </div>
      <div className="flex justify-between mt-1">
        <span className="text-xs text-gray-300 font-mono">{earned.toLocaleString()}원</span>
        <span className="text-xs text-gray-300 font-mono">{total.toLocaleString()}원</span>
      </div>
    </div>
  )
}

/* ══════════════════════════════════════════════
   APP ROOT
══════════════════════════════════════════════ */
export default function App() {
  const [started, setStarted] = useState(false)
  const [lives, setLives] = useState(MAX_LIVES)
  const [solved, setSolved] = useState<Map<string,number>>(new Map()) // id → final reward
  const [active, setActive] = useState<Quest|null>(null)
  const [coins, setCoins] = useState<Coin[]>([])
  const [poppingMoney, setPoppingMoney] = useState(false)
  const [showFinal, setShowFinal] = useState(false)
  const [penaltyFlash, setPenaltyFlash] = useState(false)

  const earned = useMemo(()=>[...solved.values()].reduce((s,v)=>s+v,0), [solved])
  const gameOver = lives === 0
  const warmupDone = WARMUP_IDS.every(id=>solved.has(id))
  const middleIds  = QUESTS.filter(q=>q.tier==='middle').map(q=>q.id)
  const middleDone = middleIds.every(id=>solved.has(id))
  const hiddenUnlocked = warmupDone && middleDone
  const hiddenDone     = solved.has('hidden')
  const finalUnlocked  = hiddenUnlocked && hiddenDone
  const allDone = finalUnlocked && solved.has('final')

  useEffect(()=>{ if(allDone) setTimeout(()=>setShowFinal(true), 900) }, [allDone])

  // Spawn coins at an element's position
  const spawnCoins = useCallback((el: HTMLElement) => {
    const rect = el.getBoundingClientRect()
    const cx = rect.left + rect.width / 2
    const cy = rect.top + rect.height / 2
    const newCoins: Coin[] = Array.from({length:5},()=>({
      id: coinId++,
      x: cx + (Math.random()-0.5)*40,
      y: cy + (Math.random()-0.5)*20,
    }))
    setCoins(prev=>[...prev, ...newCoins])
    setTimeout(()=>setCoins(prev=>prev.filter(c=>!newCoins.includes(c))), 1000)
  }, [])

  const handleSolve = useCallback((q: Quest, hintUsed: boolean, el: HTMLElement) => {
    const reward = q.baseReward - (hintUsed ? HINT_PENALTY : 0)
    setSolved(prev=>new Map([...prev, [q.id, reward]]))
    setActive(null)
    spawnCoins(el)
    setTimeout(()=>{ setPoppingMoney(true); setTimeout(()=>setPoppingMoney(false), 450) }, 200)
  }, [spawnCoins])

  const handleWrong = useCallback(()=>{
    setLives(l=>Math.max(0, l-1))
  }, [])

  const isLocked = (q: Quest): boolean => {
    if (q.tier==='warmup') return false
    if (q.tier==='middle') {
      const idx = middleIds.indexOf(q.id)
      return idx>0 && !solved.has(middleIds[idx-1])
    }
    if (q.tier==='hidden') return !hiddenUnlocked
    if (q.tier==='final')  return !finalUnlocked
    return false
  }

  const solvedInTier = (tier: Tier) => QUESTS.filter(q=>q.tier===tier && solved.has(q.id)).length
  const totalInTier  = (tier: Tier) => QUESTS.filter(q=>q.tier===tier).length

  if (!started) return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center px-6 text-center">
      <div className="text-7xl mb-5 animate-bounce">🎂</div>
      <h1 className="shimmer-red text-4xl font-black mb-1 tracking-tight">생일 방탈출</h1>
      <p className="text-gray-400 font-mono text-xs mb-8">BIRTHDAY ESCAPE ROOM</p>

      <div className="w-full max-w-sm bg-white border-2 border-red-100 rounded-3xl p-6 mb-6 text-left shadow-sm">
        <p className="text-gray-600 text-sm leading-relaxed mb-5">
          총 <span className="text-red-600 font-black">{TOTAL_BASE.toLocaleString()}원</span> 상금이 걸린 방탈출에 오신 걸 환영해!
          퀘스트를 깰수록 상금이 쌓여.
        </p>

        <div className="space-y-2 mb-5">
          {(['warmup','middle','hidden','final'] as Tier[]).map(tier=>{
            const cfg = TIER[tier]
            const qs = QUESTS.filter(q=>q.tier===tier)
            const tot = qs.reduce((s,q)=>s+q.baseReward,0)
            return (
              <div key={tier} className="flex items-center gap-3 text-sm">
                <div className="w-2 h-2 rounded-full shrink-0" style={{background:cfg.color}} />
                <span className="text-gray-600 flex-1 text-xs">{cfg.label} ({qs.length}개)</span>
                <span className="font-black text-xs tabular-nums" style={{color:cfg.color, fontFamily:'JetBrains Mono,monospace'}}>
                  {tot.toLocaleString()}원
                </span>
              </div>
            )
          })}
          <div className="border-t border-gray-100 pt-2 flex items-center justify-between">
            <span className="text-gray-400 text-xs font-mono">힌트 패널티</span>
            <span className="text-red-500 text-xs font-black font-mono">-{HINT_PENALTY.toLocaleString()}원/회</span>
          </div>
        </div>

        <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-center">
          <p className="text-red-600 font-bold text-sm">❤️ 기회는 단 {MAX_LIVES}번!</p>
          <p className="text-red-400 text-xs">5번 틀리면 더 이상 도전 불가</p>
        </div>
      </div>

      <button
        onClick={()=>setStarted(true)}
        className="pulse-red rounded-2xl px-10 py-4 font-black text-white text-lg cursor-pointer transition-all"
        style={{background:'#dc2626'}}
        onMouseEnter={e=>{ e.currentTarget.style.background='#b91c1c' }}
        onMouseLeave={e=>{ e.currentTarget.style.background='#dc2626' }}
      >
        시작 →
      </button>
    </div>
  )

  return (
    <div className="min-h-screen bg-white">
      <CoinOverlay coins={coins} />
      {active && (
        <QuestModal
          quest={active}
          livesLeft={lives}
          onSolve={handleSolve}
          onWrong={handleWrong}
          onClose={()=>setActive(null)}
        />
      )}
      {showFinal && <FinalScreen earned={earned} onClose={()=>{ setShowFinal(false); setStarted(false); setSolved(new Map()); setLives(MAX_LIVES) }} />}

      <Header earned={earned} lives={lives} poppingMoney={poppingMoney} />

      <div className="max-w-md mx-auto pt-5 pb-12">
        {/* Title */}
        <div className="text-center px-4 mb-5">
          <h1 className="font-black text-xl text-gray-900">🎂 생일 방탈출</h1>
          <p className="text-gray-400 font-mono text-xs mt-0.5">
            {solved.size} / {QUESTS.length} 클리어 · {lives > 0 ? `기회 ${lives}회 남음` : '기회 소진'}
          </p>
        </div>

        {/* Reward progress */}
        <RewardProgress earned={earned} total={TOTAL_BASE} />

        {/* Game over banner */}
        {gameOver && <GameOverBanner earned={earned} />}

        {/* Warmup */}
        <div className="px-4 mb-5">
          <TierHeader tier="warmup" earnedCount={solvedInTier('warmup')} total={totalInTier('warmup')} />
          <div className="space-y-2">
            {QUESTS.filter(q=>q.tier==='warmup').map(q=>(
              <QuestCard key={q.id} quest={q} solved={solved.has(q.id)} locked={isLocked(q)} gameOver={gameOver} onClick={()=>setActive(q)} />
            ))}
          </div>
        </div>

        {/* Middle */}
        <div className="px-4 mb-5">
          <TierHeader tier="middle" earnedCount={solvedInTier('middle')} total={totalInTier('middle')} />
          <div className="space-y-2">
            {QUESTS.filter(q=>q.tier==='middle').map(q=>(
              <QuestCard key={q.id} quest={q} solved={solved.has(q.id)} locked={isLocked(q)} gameOver={gameOver} onClick={()=>setActive(q)} />
            ))}
          </div>
        </div>

        {/* Hidden */}
        <div className="px-4 mb-5">
          <TierHeader tier="hidden" earnedCount={solvedInTier('hidden')} total={totalInTier('hidden')} />
          {hiddenUnlocked ? (
            <QuestCard quest={QUESTS.find(q=>q.tier==='hidden')!} solved={solved.has('hidden')} locked={false} gameOver={gameOver} onClick={()=>setActive(QUESTS.find(q=>q.tier==='hidden')!)} />
          ) : (
            <div className="rounded-2xl px-4 py-3 text-center bg-amber-50 border border-dashed border-amber-200">
              <p className="text-amber-500 text-xs font-mono">🔒 워밍업 + 미들 보스를 모두 클리어해야 등장</p>
            </div>
          )}
        </div>

        {/* Final */}
        <div className="px-4 mb-5">
          <TierHeader tier="final" earnedCount={solvedInTier('final')} total={totalInTier('final')} />
          {finalUnlocked ? (
            <QuestCard quest={QUESTS.find(q=>q.tier==='final')!} solved={solved.has('final')} locked={false} gameOver={gameOver} onClick={()=>setActive(QUESTS.find(q=>q.tier==='final')!)} />
          ) : (
            <div className="rounded-2xl px-4 py-3 text-center bg-red-50 border border-dashed border-red-200">
              <p className="text-red-400 text-xs font-mono">🔒 히든 보너스까지 클리어해야 열려</p>
            </div>
          )}
        </div>

        <p className="text-center text-gray-200 font-mono text-xs">
          총 {TOTAL_BASE.toLocaleString()}원 도전 중
        </p>
      </div>
    </div>
  )
}
